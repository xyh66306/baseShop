<template>
	<view>

		<view class="content">

			<!-- 条件筛选 -->
			<view class="screen">
				<view class="screen-item" @click="comprehensive">
					<text class="screen-item-text">综合</text>
					<view class="screen-item-icon">
						<image v-if="searchData.order.key == 'sort' && searchData.order.sort == 'asc'"
							class="screen-item-icon-img" src="/static/image/bottom-black.png"></image>
						<image v-else class="screen-item-icon-img" src="/static/image/bottom-gray.png"></image>
					</view>
				</view>
				<view class="screen-item" @click="priceSort">
					<text class="screen-item-text">价格</text>
					<view class="screen-item-icon">
						<image v-if="searchData.order.key == 'price' && searchData.order.sort == 'asc'"
							class="screen-item-icon-img" src="/static/image/top-black.png"></image>
						<image v-else-if="!(searchData.order.key == 'price' && searchData.order.sort == 'asc')"
							class="screen-item-icon-img" src="/static/image/top-gray.png"></image>
						<image v-if="searchData.order.key == 'price' && searchData.order.sort == 'desc'"
							class="screen-item-icon-img" src="/static/image/bottom-black.png"></image>
						<image v-if="!(searchData.order.key == 'price' && searchData.order.sort == 'desc')"
							class="screen-item-icon-img" src="/static/image/bottom-gray.png"></image>
					</view>
				</view>
				<view class="screen-item" @click="salesVolume">
					<text class="screen-item-text">销量</text>
					<view class="screen-item-icon">
						<image v-if="searchData.order.key == 'buy_count' && searchData.order.sort == 'asc'"
							class="screen-item-icon-img" src="/static/image/top-black.png"></image>
						<image v-else-if="!(searchData.order.key == 'buy_count' && searchData.order.sort == 'asc')"
							class="screen-item-icon-img" src="/static/image/top-gray.png"></image>
						<image v-if="searchData.order.key == 'buy_count' && searchData.order.sort == 'desc'"
							class="screen-item-icon-img" src="/static/image/bottom-black.png"></image>
						<image v-if="!(searchData.order.key == 'buy_count' && searchData.order.sort == 'desc')"
							class="screen-item-icon-img" src="/static/image/bottom-gray.png"></image>
					</view>
				</view>
				<!-- <view class="screen-item">
				<view class="screen-item-icon" style-type="button" :current="current" @click="listGrid">
					<image class="list-grid" :src="current == 0 ? 
						'/static/image/switch-ic-side-2.png' : '/static/image/switch-ic-list.png'" ></image>
				</view>
			</view> -->
				<view class="screen-item" v-if="screents" @click="toshow()">
					<text class="screen-item-text">筛选</text>
					<image class="filter-img" src="/static/image/top.png"></image>
				</view>
				<view class="screen-item" v-else-if="!screents" @click="toclose()">
					<text class="screen-item-text">筛选</text>
					<image class="filter-img" src="/static/image/bottom.png"></image>
				</view>
			</view>

			<!-- 高级赛选 -->
			<lvv-popup position="top" ref="lvvpopref" style="background: none;">
				<view class="fliter-c">
					<scroll-view scroll-y="true" style="height: 100%;">
						<view class="fliter-item">
							<view class="cell-item right-img">
								<view class="cell-item-hd">
									<view class="cell-hd-title">价格区间</view>
								</view>
							</view>
							<view class="fliter-i-c">
								<view class="fic-item"><input class="fic-item-input" type="number" v-model="sPrice" />
								</view>
								<view class="fic-item-line"></view>
								<view class="fic-item"><input class="fic-item-input" type="number" v-model="ePrice" />
								</view>
							</view>
						</view>
						<view class="fliter-item" v-if="cat_list.length > 0">
							<view class="cell-item right-img">
								<view class="cell-item-hd">
									<view class="cell-hd-title">分类</view>
								</view>
							</view>
							<view class="fliter-i-c">
								<view v-for="item in cat_list" :key="item.goods_cat_id"
									v-if="item.goods_cat_id && item.name"
									@click="selectKey('cat_list', item.goods_cat_id)">
									<view class="fic-item" v-if="!item.isSelect">
										<view class="fic-item-text two-line">{{ item.name }}</view>
									</view>
									<view class="fic-item fic-item-active" v-else-if="item.isSelect">
										<view class="fic-item-text two-line">{{ item.name }}</view>
									</view>
								</view>
							</view>
						</view>
						<view class="fliter-item" v-if="brand_list.length > 0">
							<view class="cell-item right-img">
								<view class="cell-item-hd">
									<view class="cell-hd-title">品牌</view>
								</view>
							</view>
							<view class="fliter-i-c">
								<view v-for="item in brand_list" :key="item.brand_id" v-if="item.brand_id && item.name"
									@click="selectKey('brand_list', item.brand_id)">
									<view class="fic-item" v-if="!item.isSelect">
										<view class="fic-item-text two-line">{{ item.name }}</view>
									</view>
									<view class="fic-item fic-item-active" v-else-if="item.isSelect">
										<view class="fic-item-text two-line">{{ item.name }}</view>
									</view>
								</view>
							</view>
						</view>
						<view class="fliter-item" v-if="label_list.length > 0">
							<view class="cell-item right-img">
								<view class="cell-item-hd">
									<view class="cell-hd-title">标签</view>
								</view>
							</view>
							<view class="fliter-i-c">
								<view v-for="item in label_list" :key="item.id" v-if="item.id && item.name"
									@click="selectKey('label_list', item.id)">
									<view class="fic-item" v-if="!item.isSelect">
										<view class="fic-item-text two-line">{{ item.name }}</view>
									</view>
									<view class="fic-item fic-item-active" v-else-if="item.isSelect">
										<view class="fic-item-text two-line">{{ item.name }}</view>
									</view>
								</view>
							</view>
						</view>
					</scroll-view>
					<view class="button-bottom">
						<button class="btn btn-square" @click="toclose()">关闭</button>
						<button class="btn btn-b btn-square" @click="filterOk()">确定</button>
					</view>
				</view>
			</lvv-popup>

			<!-- 商品列表 -->
			<view class="goods" v-if="goodsList.length > 0">
				<view class="goodsList" @tap="goDetail" :data-id="item.id" v-for="(item, index) in goodsList">
					<img class="imgBox" :src="item.image_url" alt="" mode="" />
					<view class="desc">
						<view class="goodsName">{{ item.name }}</view>
						<view class="goodsdes" v-if="item.brief">{{ item.brief }}</view>
						<view class="price" v-if="item.open_point == 1">
							{{ item.point }}
							<text class="font12">积分</text>
							<text>+¥{{ parseFloat(item.price)}}</text>
						</view>
						<view class="price" v-if="item.open_point == 2">
							{{ item.point }}
							<text class="font12">积分</text>
						</view>
						<view class="price-box">
							<view class="primar" >{{ item.mktprice > 0 ? '￥' + parseFloat(item.mktprice) : '' }}</view>
							<view class="pay">兑换</view>
						</view>
					</view>
				</view>
			</view>
			<view class="goods-none" v-else>
			</view>
			<uni-load-more :status="loadStatus"></uni-load-more>
		</view>
	</view>
</template>
<script>
	import lvvPopup from '@/components/lvv-popup/lvv-popup.vue';
	export default {
		components: {},
		data() {
			return {
				tabCurrent: 0,
				current: 0,
				id: '',
				showView: false,
				goodsList: [],
				minPrice: '',
				maxPrice: '',
				ajaxStatus: false,
				loading: true,
				loadingComplete: false,
				nodata: false,
				toView: '',
				searchData: {
					where: {
						open_point: [1, 2],
					},
					limit: 10,
					page: 1,
					exchange: 0, //是否过滤只能兑换的
					order: {
						key: 'sort',
						sort: 'asc'
					}
				},
				searchKey: "请输入关键词搜索", //关键词
				alllist: true,
				allgrid: false,
				screents: true,
				screentc: false,
				sPrice: '',
				ePrice: '',
				brand_list: [],
				cat_list: [],
				label_list: [],
				loadStatus: 'more',
			};
		},
		//加载执行
		onLoad: function(options) {
			var where = {};
			if (options.id) {
				where = {
					cat_id: options.id
				};
			}
			if (options.key) {
				where = {
					search_name: options.key
				};
				this.searchKey = options.key;
			}
			if (options.type) {
				if (options.type == 'hot') {
					where = {
						hot: true
					};
				}
				if (options.type == 'recommend') {
					where = {
						recommend: true
					};
				}
			}
			if (options.cat_id) {
				where.cat_id = options.cat_id;
			}
			if (options.brand_id) {
				where.brand_id = options.brand_id;
			}
			if (options.hot) {
				where.hot = options.hot;
			}
			if (options.recommend) {
				where.recommend = options.recommend;
			}
			if (options.label_id) {
				where.label_id = options.label_id;
			}
			//是否过滤可以兑换
			if (options.exchange) {
				where.exchange = options.exchange
			}
			this.setSearchData({
				where: where
			});

			this.getGoods();
		},
		onShow() {
			uni.setNavigationBarTitle({
				title: "商品列表"
			})
		},
		components: {
			lvvPopup
		},
		methods: {
			listGrid() {
				if (this.current == 0) {
					this.current = 1;
				} else {
					this.current = 0;
				}
			},
			//设置查询条件
			setSearchData: function(searchData, clear = false) {
				var sd = this.searchData;
				this.searchData = this.$common.deepCopy(sd, searchData);
				if (clear) {
					// this.goodsList = [];
				}
			},
			onChangeShowState: function() {
				var _this = this;
				_this.showView = !_this.showView;
			},
			//点击综合排序
			comprehensive: function() {
				this.tabCurrent = 0
				this.setSearchData({
						order: {
							key: 'sort',
							sort: 'asc'
						},
						page: 1
					},
					true
				);
				this.getGoods(true);
			},
			//销量
			salesVolume: function() {
				this.tabCurrent = 2
				if (this.searchData.order.key == 'buy_count') {
					if (this.searchData.order.sort == 'desc') {
						this.searchData.order.sort = 'asc';
					} else {
						this.searchData.order.sort = 'desc';
					}
				} else {
					this.searchData.order = {
						key: 'buy_count',
						sort: 'desc'
					};
				}
				this.searchData.page = 1; //从第一页重新显示
				this.setSearchData(this.searchData, true);
				this.getGoods(true);
			},
			//价格排序
			priceSort: function() {
				this.tabCurrent = 1
				if (this.searchData.order.key == 'price') {
					if (this.searchData.order.sort == 'desc') {
						this.searchData.order.sort = 'asc';
					} else {
						this.searchData.order.sort = 'desc';
					}
				} else {
					this.searchData.order = {
						key: 'price',
						sort: 'asc'
					};
				}
				this.searchData.page = 1; //从第一页重新显示
				this.setSearchData(this.searchData, true);
				this.getGoods(true);
			},
			//页面相关事件处理函数--监听用户下拉动作
			onPullDownRefresh: function() {},
			//跳转到商品详情页面
			goodsDetail: function(id) {
				let url = '/pages/goods/index/index?id=' + id;
				this.$common.navigateTo(url);
			},
			//取得商品数据
			getGoods: function(flag) {
				var _this = this;
				if (_this.ajaxStatus) {
					return false;
				}
				_this.ajaxStatus = true;
				_this.loading = true;
				_this.loadingComplete = false;
				_this.nodata = true;
				_this.loadStatus = 'loading'
				//如果已经没有数据了，就不取数据了，直接提示已经没有数据
				if (_this.loadingComplete) {
					_this.$common.errorToShow("没有更多数据了");
					return false;
				}
				

				_this.$api.goodsList(_this.conditions(), function(res) {
					_this.loadStatus = res.data.list && res.data.list.length >= _this.searchData.limit ?
						'more' : 'noMore'
					if (res.status) {
						//判是否没有数据了，只要返回的记录条数小于总记录条数，那就说明到底了，因为后面没有数据了
						var isEnd = false;
						if (res.data.list.length < _this.searchData.limit) {
							isEnd = true;
						}
						//判断是否为空
						var isEmpty = false;
						if (_this.searchData.page == 1 && res.data.list.length == 0) {
							isEmpty = true;
						}

						if (res.data.class_name != '') {
							uni.setNavigationBarTitle({
								title: res.data.class_name
							});
						} else {
							if (res.data.where && res.data.where.search_name && res.data.where.search_name !=
								'') {
								uni.setNavigationBarTitle({
									title: "商品搜索"
								});
							}
						}
						if (flag) {
							_this.goodsList = []
						}
						_this.goodsList = _this.goodsList.concat(res.data.list);
						_this.ajaxStatus = false;
						_this.loading = !isEnd && !isEmpty;
						_this.toView = '';
						_this.loadingComplete = isEnd && !isEmpty;
						_this.nodata = isEmpty;
						if (res.data.filter) {
							let filter = res.data.filter;
							if (filter.brand_ids) {
								for (let i = 0; i < filter.brand_ids.length; i++) {
									filter.brand_ids[i].isSelect = false;
								}
								_this.brand_list = filter.brand_ids;
							}
							if (filter.goods_cat) {
								for (let i = 0; i < filter.goods_cat.length; i++) {
									filter.goods_cat[i].isSelect = false;
								}
								_this.cat_list = filter.goods_cat;
							}
							if (filter.label_ids) {
								for (let i = 0; i < filter.label_ids.length; i++) {
									filter.label_ids[i].isSelect = false;
								}
								_this.label_list = filter.label_ids;
							}
						}
					}
				});
			},
			//上拉加载
			lower: function() {
				var _this = this;
				_this.toView = 'loading';

				if (!_this.loadingComplete) {
					_this.setSearchData({
						page: _this.searchData.page + 1
					});
					_this.getGoods();
				}
			},
			listgrid: function() {
				let _this = this;
				if (_this.alllist) {
					_this.allgrid = true;
					_this.listgrid = true;
					_this.alllist = false;
				} else {
					_this.allgrid = false;
					_this.listgrid = false;
					_this.alllist = true;
				}
			},
			// 统一返回筛选条件 查询条件 分页
			conditions() {
				let data = this.searchData;
				var newData = {};
				newData = this.$common.deepCopy(newData, data);
				//把data里的where换成json
				if (data.where) {
					newData.where = JSON.stringify(data.where);
				}
				//把排序换成字符串
				if (data.order) {
					var sort = data.order.key + ' ' + data.order.sort;
					if (data.order.key != 'sort') {
						sort = sort + ',sort asc'; //如果不是综合排序，增加上第二个排序优先级排序
					}
					newData.order = sort;
				} else {
					newData.order = 'sort asc';
				}
				let userToken = this.$db.get('userToken')
				if (userToken) {
					newData.token = userToken
				}
				return newData;
			},
			//老搜索
			search() {
				this.setSearchData({
						page: 1,
						where: {
							search_name: this.keyword
						}
					},
					true
				);
				this.getGoods(true);
			},
			//筛选条件弹出窗口
			toshow() {
				this.$refs.lvvpopref.show();
				this.screents = false;
				this.screentc = true;
			},
			//关闭筛选
			toclose() {
				this.$refs.lvvpopref.close();
				this.screentc = false;
				this.screents = true;
			},
			//取消筛选
			filterNo() {
				this.ePrice = '';
				this.sPrice = '';
				for (let i = 0; i < this.cat_list.length; i++) {
					this.cat_list[i].isSelect = false;
				}
				for (let i = 0; i < this.brand_list.length; i++) {
					this.brand_list[i].isSelect = false;
				}
				for (let i = 0; i < this.label_list.length; i++) {
					this.label_list[i].isSelect = false;
				}
				this.filterOk();
				this.toclose();
			},
			goDetail(e) {
				let id = e.currentTarget.dataset.id;
				uni.navigateTo({
					url: '/pointmall/point/detail?id=' + id
				});
			},
			//确认筛选
			filterOk() {
				let data = this.searchData;

				//获取分类
				// data.where.cat_id = '';
				for (let i = 0; i < this.cat_list.length; i++) {
					if (this.cat_list[i].isSelect) {
						data.where.cat_id = this.cat_list[i].goods_cat_id;
					}
				}

				//获取多个品牌
				let brand_ids = '';
				for (let i = 0; i < this.brand_list.length; i++) {
					if (this.brand_list[i].isSelect) {
						brand_ids += this.brand_list[i].brand_id + ',';
					}
				}
				if (brand_ids) {
					brand_ids = brand_ids.substr(0, brand_ids.length - 1);
				}
				data.where.brand_id = brand_ids;

				//获取标签
				data.where.label_id = '';
				for (let i = 0; i < this.label_list.length; i++) {
					if (this.label_list[i].isSelect) {
						data.where.label_id = this.label_list[i].id;
					}
				}

				//价格区间
				data.where.price_f = '';
				data.where.price_t = '';
				if (
					this.sPrice * 1 < 0 ||
					(this.ePrice != '' && this.ePrice <= 0) ||
					this.ePrice * 1 < 0 ||
					(this.sPrice * 1 > this.ePrice * 1 && this.sPrice != '' && this.ePrice != '')
				) {
					this.$common.errorToShow("价格区间有误");
					return false;
				} else {
					data.where.price_f = this.sPrice;
					data.where.price_t = this.ePrice;
				}

				this.setSearchData(data, true);
				this.getGoods(true);
				this.toclose();
			},
			//选择
			selectKey(type, id) {
				//分类一次只能选择一个
				if (type == 'cat_list') {
					for (let i = 0; i < this.cat_list.length; i++) {
						if (this.cat_list[i].goods_cat_id == id) {
							this.cat_list[i].isSelect = this.cat_list[i].isSelect ? false : true;
						} else {
							this.cat_list[i].isSelect = false;
						}
					}
				}

				if (type == 'brand_list') {
					for (let i = 0; i < this.brand_list.length; i++) {
						if (this.brand_list[i].brand_id == id) {
							this.brand_list[i].isSelect = this.brand_list[i].isSelect ? false : true;
						}
					}
				}

				if (type == 'label_list') {
					for (let i = 0; i < this.label_list.length; i++) {
						if (this.label_list[i].id == id) {
							this.label_list[i].isSelect = this.label_list[i].isSelect ? false : true;
						} else {
							this.label_list[i].isSelect = false;
						}
					}
				}
			}
		},
		onReachBottom() {
			if (this.loadStatus === 'more') {
				this.getGoods()
			}
		},
		// #ifdef MP-ALIPAY
		onChangeShowState_show: function() {
			var that = this;
			that.setData({
				showView: (that.showView = true)
			});
		},
		onChangeShowState_hid: function() {
			var that = this;
			that.setData({
				showView: (that.showView = false)
			});
		}
		// #endif
	};
</script>

<style lang="scss" scoped>
	.img-list {
		background: #FFFFFF;
		padding-bottom: 200rpx;

		&-item {
			.goods-buy {
				display: flex;
				align-items: center;
				justify-content: space-between;
			}

			&:last-child {
				border: 0;
			}
		}
	}

	page {
		// background-color: #fff;
	}

	.search {
		position: fixed;
		z-index: 997;
		/*  #ifdef  H5  */
		top: 44px;
		/*  #endif  */
	}

	.screen {
		width: 100%;
		padding: 10upx 26upx 20upx;
		margin-bottom: 2upx;
		background-color: #fff;
		position: fixed;
		height: 80rpx;
		display: flex;
		justify-content: space-around;
		align-items: center;
		/*  #ifdef  H5  */
		top: 80rpx;
		/*  #endif  */
		/*  #ifndef H5 */
		top: 0upx;
		/*  #endif  */
		display: flex;
		z-index: 997;
	}

	.screen-item {
		width: 20%;
		height: 50upx;
		display: flex;
		position: relative;
		align-items: center;
		justify-content: center;
	}

	.screents {
		border-left: 2upx solid #eee;
	}

	.screen-item-text {
		font-size: 24upx;
		color: #333;
		margin-right: 8upx;

		&.active {
			color: $gray-8;
		}
	}

	.screen-item-icon {
		display: inline-block;
	}

	.screen-item-icon-img {
		width: 18rpx;
		height: 12rpx;
		display: block;
	}

	.screen-item-icon .screen-item-icon-img:first-child {
		margin-bottom: 4upx;
	}

	.list-grid {
		width: 44upx;
		height: 44upx;
		float: left;
	}

	.filter-img {
		width: 18upx;
		height: 8upx;
	}

	.img-grids {
		padding-bottom: 26upx;

		.img-grids-wrap {
			display: flex;
			justify-content: space-between;
			flex-wrap: wrap;
			padding: 0 28rpx;
			padding-top: 20rpx;
		}

		.img-grids-item {
			width: 308rpx;
			margin: 0;
			margin-bottom: 20rpx;

			.img-grids-item-t {
				width: 308rpx;
			}
		}
	}

	.img-grids>view,
	.img-list>view {
		overflow: hidden;
	}

	.scroll-Y {
		/*  #ifdef  H5  */
		// height: calc(100vh - 44px);
		margin-top: 120rpx;
		/*  #endif  */
		/*  #ifndef H5 */
		height: calc(100vh - 186upx);
		padding-top: 186rpx;
		/*  #endif  */
	}

	.search-input-p {
		color: #888;
	}

	.order-none {
		text-align: center;
		padding: 200upx 0;
	}

	.order-none-img {
		width: 274upx;
		height: 274upx;
	}

	.fliter-c {
		width: 100%;
		/*  #ifdef  H5  */
		height: calc(100% - 400rpx);
		top: 160rpx;
		/*  #endif  */
		/*  #ifndef H5 */
		height: calc(100% - 300upx);
		top: 81upx;
		/*  #endif  */
		background: #ffffff;
		position: absolute;
		left: 0;

		padding-bottom: 90upx;
	}

	.fliter-item {}

	.fliter-item .cell-item {
		border-bottom: none;
	}

	.fliter-i-c {
		padding: 0 26upx;
		overflow: hidden;
	}

	.fic-item {
		display: inline-block;
		float: left;
		width: 160upx;
		margin-right: 14upx;
		height: 70upx;
		background-color: #f1f1f1;
		text-align: center;
		font-size: 24upx;
		margin-bottom: 14upx;
		color: #333;
		padding: 0 10upx;
	}

	.fic-item-active {
		background-color: #ff7159;
		color: #fff;
	}

	.fic-item-text {
		position: relative;
		top: 50%;
		transform: translateY(-50%);
	}

	.fic-item:nth-child(4n) {
		margin-right: 0;
	}

	.fic-item-line {
		float: left;
		margin: 34upx 18upx 0 0;
		width: 50upx;
		height: 2upx;
		border-bottom: 2upx solid #ccc;
	}

	.fic-item-input {
		position: relative;
		top: 50%;
		transform: translateY(-50%);
	}

	/* #ifdef MP-ALIPAY */
	.hide {
		display: none;
	}

	.show {
		display: block;
	}

	/* #endif */
	.square {
		border-radius: 0;
	}

	.radius {
		border-radius: 12upx;
	}

	.button-bottom {
		display: flex;
		align-items: center;
		bottom: 140rpx;
	}

	.goods-salesvolume {
		margin: 0;
	}

	.goods {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		border-radius: 10rpx;
		overflow: hidden;
		padding: 28rpx;
		color: #1a1a1a;
		/*  #ifdef  H5  */
		margin-top: 40rpx;
		/*  #endif  */
		/*  #ifndef H5 */
		margin-top: 50rpx;
		/*  #endif  */
	}

	.goodsList {
		width: 340rpx;
		margin-top: 20rpx;
		border-radius: 10rpx;
		overflow: hidden;
		box-sizing: border-box;
	}

	.goodsName {
		height: 44rpx;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
		color: #0e1433;
		font-size: 26rpx;
	}

	.goodsdes {
		color: #7e818c;
		height: 68rpx;
		font-size: 24rpx;
		overflow: hidden;
		text-overflow: ellipsis; //当对象内文本溢出时显示省略标记
		display: -webkit-box;
		-webkit-line-clamp: 2; //这边的2指的是两行
		-webkit-box-orient: vertical;
		margin: 12rpx 0 16rpx;
	}

	.imgBox {
		width: 340rpx;
		height: 340rpx;
	}

	.desc {
		width: 340rpx;
		/* display: flex; */
		flex-direction: column;
		justify-content: space-around;
		padding: 0 22rpx 30rpx;
		background: #fff;
		margin-top: -8rpx;
	}

	.priceType {
		/* width: 126rpx; */
		height: 42rpx;
		border: 1px solid #fec200;
		border-radius: 8rpx;
		font-size: 24rpx;
		color: #fec200;
		text-align: center;
		margin: 12rpx 4rpx;
		line-height: 42rpx;
		display: inline-block;
		padding: 0 10rpx;
	}

	.price {
		color: #FF4444;
		font-size: 28rpx;
		// font-size: 36rpx;
		// font-weight: 700;
	}

	.price-box {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-top: 4rpx;

		.primar {
			text-decoration: line-through;
			color: #7e818c;
			font-size: 24rpx;
		}

		.pay {
			width: 80rpx;
			height: 44rpx;
			background: #ff4444;
			border-radius: 8rpx;
			line-height: 44rpx;
			text-align: center;
			color: #ffffff;
			font-size: 24rpx;
		}
	}
	
	.goods-none {
		padding: 100px 0 0;
	}
</style>