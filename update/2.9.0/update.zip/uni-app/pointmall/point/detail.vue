<template>
	<view>
		<view class="wrap">
			<customBack></customBack>
			<custome-swiper :imgArr="goodsInfo.album" :video="goodsInfo.video" :indicatorDots="false" :showNum="true"
				v-if="goodsInfo.album && goodsInfo.album.length>0" />
			<view class="info ">
				<view class="displayBet">
					<view class="integral">
						{{ goodsInfo.point || 0 }}
						<text class="font12">积分</text>
						<text class="font12" v-if="goodsInfo.open_point==1">+￥{{goodsInfo.price}}</text>
					</view>
				</view>
				<view class="desc">{{ goodsInfo.name || '' }}</view>
			</view>
			<view class="goods-content">
				<view class="goodsDe">
					<view class="title">商品详情</view>
					<jshopContent :content="goodsInfo.intro" v-if="goodsInfo.intro"></jshopContent>
				</view>
			</view>
			<view class="bottom button-bottom">
				<view class="">
					<view class="" v-if="goodsInfo.open_point == 1">
						<text class="fw" style="color: #fe4706;">支付:</text>
						<text style="color: #fe4706;">{{ goodsInfo.point || 0 }}</text>
						积分
						<text style="color: #fe4706;">+¥{{ goodsInfo.price }}</text>
					</view>
					<view class="" v-if="goodsInfo.open_point == 2">
						<text class="fw" style="color: #fe4706;">支付:</text>
						<text style="color: #fe4706;">{{ goodsInfo.point || 0 }}</text>
						积分
					</view>
					<view class="">可用积分:{{ userInfo.point || 0 }} 积分</view>
				</view>
				<view class="exchange" @click="toshow(2)" v-if="open_point_exchange == 1">立即兑换 </view>
				<view class="exchange-tips" v-else> 暂未开启 </view>
			</view>

			<!-- 底部按钮end -->
			<add-shop ref="addShop" @bindChange="bindChange" v-if="JSON.stringify(product) != '{}'" :submitStatus="submitStatus"
				:minNums="minNums" :maxNums="maxNums" :buyNum="buyNum" :unit="goodsInfo.unit" @clickHandle="clickHandle"
				@changeSpes="changeSpes" :product="product" />
		</view>
	</view>
</template>

<script>
	import customBack from '@/components/custome/back/index.vue';
	import addShop from '@/components/custome/add-shop/pointmall.vue';
	import spec from '@/components/custome/spec/index.vue';
	import jshopContent from '@/components/jshop/jshop-content.vue'; //视频和文本解析组件
	import customeSwiper from '@/components/custome/swiper/index.vue';
	import {
		mapState
	} from 'vuex'
	export default {
		components: {
			spec,
			jshopContent,
			customeSwiper,
			addShop,
			customBack
		},
		data() {
			return {
				goodsId: 0, // 商品id
				goodsInfo: {
					album: []
				}, // 商品详情
				buyNum: 1,
				minBuyNum: 1, // 最小可购买数量
				product: {},
				userInfo: {},
				type: 2, //立即购买
				submitStatus: false,
				maxNums: 1
			};
		},
		computed: {
			...mapState({
				open_point_exchange: state => state.config.open_point_exchange
			}),
			// 规格切换计算规格商品的 可购买数量
			minNums() {
				return this.product.stock > this.minBuyNum ? this.minBuyNum : this.product.stock;
			},
			// 判断商品是否是多规格商品  (为了兼容小程序 只能写在计算属性里面了)
			isSpes() {
				if (this.product.hasOwnProperty('default_spes_desc') && Object.keys(this.product.default_spes_desc)
					.length) {
					return true;
				} else {
					return false;
				}
			}
		},
		onLoad(options) {
			if (options.id) {
				this.goodsId = options.id;
				this.getGoodsDetail();
			}
			var _this = this;
			if (this.$db.get('userToken')) {
				this.$api.userInfo({}, res => {
					if (res.status) {
						_this.userInfo = res.data;
					}
				});
			}
		},
		methods: {
			// 获取商品详情
			getGoodsDetail() {
				let data = {
					id: this.goodsId
				};

				// 如果用户已经登录 要传用户token
				let userToken = this.$db.get('userToken');

				if (userToken) {
					data['token'] = userToken;
				}
				this.$api.pointDetail(data, res => {
					if (res.status == true) {
						let info = res.data;
						if (info.length <= 0) {
							this.$common.errorToShow('商品信息不存在', () => {
								uni.navigateBack({
									delta: 1
								});
							});
						}
						let products = res.data.product;
						this.goodsInfo = info;
						this.isfav = this.goodsInfo.isfav === 'true' ? true : false;
						this.product = this.spesClassHandle(products);
					} else {
						this.$common.errorToShow(res.msg, () => {
							uni.navigateBack({
								delta: 1
							});
						});
					}
				});
			},
			// 切换商品规格
			changeSpes(obj) {
				let index = obj.v;
				let key = obj.k;

				let userToken = this.$db.get('userToken');
				let tmp_default_spes_desc = JSON.parse(this.product.default_spes_desc);

				//console.log('tmp_default_spes_desc', tmp_default_spes_desc, index, key);
				if (tmp_default_spes_desc[index][key].hasOwnProperty('product_id') && tmp_default_spes_desc[index][key]
					.product_id) {
					// this.$refs.spec.changeSpecData();
					this.$api.getProductInfo({
							id: tmp_default_spes_desc[index][key].product_id,
							token: userToken
						},
						res => {
							if (res.status == true) {
								// 切换规格判断可购买数量
								this.buyNum = res.data.stock > this.minBuyNum ? this.minBuyNum : res.data.stock;
								this.product = this.spesClassHandle(res.data);
							}
						}
					);
					uni.showLoading({
						title: '加载中'
					});
					setTimeout(function() {
						uni.hideLoading();
					}, 1000);
				}
			},
			// 多规格样式统一处理
			spesClassHandle(products) {
				// 判断是否是多规格 (是否有默认规格)
				if(typeof products.default_spes_desc == 'string'){
					products.default_spes_desc = JSON.parse(products.default_spes_desc);
				}
				
				if (products.hasOwnProperty('default_spes_desc')) {
					let spes = products.default_spes_desc;
					for (let key in spes) {
						for (let i in spes[key]) {
							if (spes[key][i].hasOwnProperty('is_default') && spes[key][i].is_default === true) {
								this.$set(spes[key][i], 'cla', 'pop-m-item selected');
							} else if (spes[key][i].hasOwnProperty('product_id') && spes[key][i].product_id) {
								this.$set(spes[key][i], 'cla', 'pop-m-item not-selected');
							} else {
								this.$set(spes[key][i], 'cla', 'pop-m-item none');
							}
						}
					}
					spes = JSON.stringify(spes).replace(/\./g, '====');
					products.default_spes_desc = spes;
				}
				return products;
			},
			// 显示modal弹出框
			toshow(type) {
				this.type = type;
				this.$refs.addShop.show();
			},
			// 关闭modal弹出框
			toclose() {
				// this.$refs.lvvpopref.close();
				this.$refs.addShop.toclose();
			},
			// 购买数量加减操作
			bindChange(val) {
				this.buyNum = val;
			},
			// 点击弹出框确定按钮事件处理
			clickHandle() {
				this.submitStatus = true;
				this.buyNow();
			},
			// 立即购买
			buyNow() {
				if (this.buyNum > 0) {
					let data = {
						product_id: this.product.id,
						nums: this.buyNum,
						type: 2, // 区分加入购物车和购买
						order_type: 10 //
					};
					this.$api.addCart(
						data,
						res => {
							if (res.status) {
								this.toclose();
								let cartIds = res.data;
								this.$common.navigateTo('/pages/goods/place-order/index?cart_ids=' + JSON.stringify(
									cartIds) + '&order_type=10');
							} else {
								this.$common.errorToShow(res.msg);
							}
						},
						res => {
							this.submitStatus = false;
						}
					);
				}
			}
		}
	};
</script>

<style scoped lang="less">
	.wrap {
		background-color: #f5f5f5;
	}

	.shopImg {
		width: 100vw;
	}

	.info {
		padding: 24rpx 28rpx;
		background-color: #fff;
	}

	.integral {
		color: #fe4706;
		font-size: 64rpx;
	}

	.font12 {
		font-size: 24upx;
	}

	.color4D {
		color: #4d4d4d;
	}

	.desc {
		font-size: 28rpx;
		font-weight: 500;
		margin-top: 8rpx;
		color: #4D4D4D !important;
	}

	.goods-content {
		background-color: #fff;
		margin-top: 26rpx;
		padding: 0 20rpx;
	}


	.goodsDe {
		background-color: #fff;
		padding: 38rpx 16rpx 160rpx;

		.title {
			text-align: center;
			margin: auto;
		}
	}

	/deep/ .pop-c {
		width: 100%;
		/* #ifdef H5 */
		max-height: 804upx;
		/* #endif */

		background: #FFFFFF;
		position: absolute;
		left: 0;
		bottom: 0;
	}

	.bottom {
		width: 100vw;
		position: fixed;
		bottom: 0;
		left: 0;
		background-color: #fff;
		height: 140rpx;
		padding: 10rpx 32rpx 28rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		color: #4d4d4d;
		z-index: 0;

		.exchange {
			width: 320rpx;
			height: 70rpx;
			background: #FF4444;
			line-height: 70rpx;
			text-align: center;
			color: #fff;
			font-size: 28rpx;
			font-weight: 500;

			&:active {
				background-color: #FF4444;
			}

			&-tips {
				color: #fe4706;
			}
		}
	}
</style>