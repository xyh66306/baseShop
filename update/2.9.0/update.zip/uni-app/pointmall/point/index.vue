<template>
	<view>
		<view class="point-home" >
			<view class="topBox">
				<image src="../static/images/jf-home-bg.png" class="topImage"></image>
				<view class="top">
					<view class='search-c' :style="{marginTop: menuButtonInfo.top + 'px', width: (335 - (menuButtonInfo.width - 10)) + 'px'}">
						<input v-model="keysword" class='search-input' placeholder-style="color: #FFFFFF" placeholder-class='search-input-p' placeholder="请输入关键字搜索"
							@confirm="searchPointGoods"></input>
					</view>
					<view class="point" @click="goPointDetail">可用积分：{{ userInfo.point || '0' }}</view>
				</view>
			</view>
			<view class="swiper-box" v-if="advert.length>0">
				<swiper class="swiper" :indicator-dots="true" :autoplay="true" indicator-active-color="#fff"
					indicator-color="rgba(255,255,255,.5)">
					<swiper-item v-for="item in advert">
						<img class="swiperImg" :src="item.img" mode="aspectFill"
							@click="showSliderInfo(item.type, item.val)" />
					</swiper-item>
				</swiper>
			</view>
			<view class="tablist">
				<view class="tabitem" v-for="item in tablist" :key="item.type" @click="clickHandle(item)">
					<image :src="item.img" mode="widthFix"></image>
					<text>{{item.label}}</text>
				</view>
			</view>
			<!-- <v-tabs :scroll="false" v-model="current" fontSize="24rpx" activeFontSize="28rpx" activeColor="#0E1433"
				lineColor="#FE6D57" bgColor="transparent" :tabs="tabs" @change="changeTab"></v-tabs> -->
			<uni-segmented-control :current="current" class="control" :values="tabs" @clickItem="changeTab"
				style-type="text" active-color="#FE6D57"></uni-segmented-control>
			<view class="goods" v-if="goodsList.length > 0">
				<view class="goodsList" @tap="goDetail" :data-id="item.id" v-for="(item, index) in goodsList">
					<img class="imgBox" :src="item.image_url" alt="" mode="" />
					<view class="desc">
						<view class="goodsName">{{ item.name ||''}}</view>
						<view class="goodsdes" >{{ item.brief||'' }}</view>
						<view class="price" v-if="item.open_point == 1">
							{{ item.point }}
							<text class="font12">积分</text>
							<text>+¥{{ parseFloat(item.price) }}</text>
						</view>
						<view class="price" v-if="item.open_point == 2">
							{{ item.point }}
							<text class="font12">积分</text>
						</view>
						<view class="price-box">
							<view class="primar">{{item.mktprice > 0 ? '￥' + parseFloat(item.mktprice) : ''}}</view>
							<view class="pay">兑换</view>
						</view>
					</view>
				</view>
			</view>
			<view class="goods-none" v-else>
				
			</view>
			<uni-load-more :status="loadStatus"></uni-load-more>
			<!-- 排行榜图标 -->
			<view class="rinkBox" @click="goRink">
				<image src="../static/images/rinkIcon.png" mode=""></image>
				<view class="">排行榜</view>
			</view>
			<jh-tabbar />
		</view>
	</view>
</template>

<script>
	import {
		apiBaseUrl
	} from '@/config/config.js'
	import {
		pointmallBanner
	} from '@/config/config.js';
	import customBack from '@/components/custome/back/index.vue';
	export default {
		components: {
			customBack
		},
		data() {
			return {
				current: 0,
				tabs: ['全部', '积分抵扣', '积分兑换'],
				userInfo: {},
				advert: [],
				searchData: {
					where: {
						open_point: [1, 2]
					},
					limit: 10,
					page: 1,
					order: {
						key: 'sort',
						sort: 'asc'
					}
				},
				loadStatus: 'more',
				goodsList: [],
				baseUrl: apiBaseUrl,
				keysword: '',
				tablist: [{
						type: 1,
						label: '积分明细',
						img: '/pointmall/static/images/point_tab1.png',
						path: '/pages/member/integral/index',
					},
					{
						type: 2,
						label: '积分规则',
						img: '/pointmall/static/images/point_tab2.png',
						path: '/pages/article/index?id=1&id_type=1',
					},
					{
						type: 3,
						label: '兑换记录',
						img: '/pointmall/static/images/point_tab3.png',
						path: '/pages/member/order/orderlist?order_type=10',
					},
					{
						type: 4,
						label: '我能兑换',
						img: '/pointmall/static/images/point_tab4.png',
						path: '/pointmall/point/goodlist?exchange=1',
					}
				],
				menuButtonInfo: {}
			};
		},
		onLoad() {
			// #ifdef MP-WEIXIN
			this.menuButtonInfo  = uni.getMenuButtonBoundingClientRect();
			// #endif
			this.getUserInfo();
			this.getBanner();
			this.getGoods();
		},
		methods: {
			//跳转积分商品列表页
			searchPointGoods() {
				if (this.keysword) {
					uni.navigateTo({
						url: '/pointmall/point/goodlist?key=' + this.keysword
					})
				} else {
					this.$common.errorToShow('请先输入您要搜索的名称或者编码');
				}

			},
			clickHandle(item) {
				uni.navigateTo({
					url: item.path
				})
			},

			//跳转排行榜
			goRink() {
				uni.navigateTo({
					url: './rink'
				})
			},
			openRule() {
				let articleId = this.$store.state.config.point_rule_id;
				this.$common.navigateTo('/pageactivity/article/index?id_type=1&id=' + articleId);
			},
			closePop() {
				this.$refs.popupRule.close()
			},
			getUserInfo() {
				let _this = this;
				if (this.$db.get('userToken')) {
					this.$api.userInfo({}, res => {
						if (res.status) {
							_this.userInfo = res.data;
						}
					});
				}
			},
			changeTab(index) {
				// console.log('当前选中的项：' + index);
				// if (index != this.current) {
					if (index == 0) {
						this.searchData.where.open_point = [1, 2];
					} else if (index == 1) {
						this.searchData.where.open_point = [1];
					} else if (index == 2) {
						this.searchData.where.open_point = [2];
						this.searchData.order.key = 'ctime';
						this.searchData.order.sort = 'desc';
					}
					this.searchData.page = 1;
					this.getGoods(true);
				// }
			},
			goDetail(e) {
				let id = e.currentTarget.dataset.id;
				uni.navigateTo({
					url: '/pointmall/point/detail?id=' + id
				});
			},
			goPointDetail() {
				uni.navigateTo({
					url: '/pagemember/integral/index'
				});
			},
			getBanner() {
				let _this = this;
				this.$api.advert({
						codes: `${pointmallBanner}`
					},
					res => {
						let result = res.data.list[`${pointmallBanner}`] || res.data.list;
						this.advert = result;
						this.tablist.forEach(function(item,idx){
							if(item.type == 2){
								var point_rule_id = _this.$store.state.config.point_rule_id;
								if(point_rule_id){
									_this.tablist[idx].path = '/pages/article/index?id='+point_rule_id+'&id_type=1';
								}
								
							}
						})
					}
				);
			},
			// 广告点击查看详情
			showSliderInfo(type, val) {
				console.log(type);
				if (type == 1) {
					if (val.indexOf('http') != -1) {
						// #ifdef H5
						window.location.href = val;
						// #endif
						// #ifndef H5
						uni.navigateTo({
							url: '/pageactivity/webview/index?src=' + val
						})
						// #endif
					} else {
						// #ifdef H5 || APP-PLUS || APP-PLUS-NVUE || MP
						if (val == '/pages/index/index' || val == '/pages/classify/classify' || val ==
							'/pages/cart/index/auction' || val == '/pages/me/me') {
							uni.reLaunch({
								url: val
							});
							return;
						} else if (val.indexOf('/pageactivity/coupon/coupon') > -1) {
							var id = val.replace('/pageactivity/coupon/coupon?id=', '');
							this.receiveCoupon(id);
						} else {
							this.$common.navigateTo(val);
							return;
						}
						// #endif
					}
				} else if (type == 2) {
					// 商品详情
					this.goodsDetail(val);
				} else if (type == 3) {
					// 文章详情
					this.$common.navigateTo('/pageactivity/article/index?id=' + val + '&id_type=1');
				} else if (type == 4) {
					// 文章列表
					this.$common.navigateTo('/pageactivity/article/list?cid=' + val);
				}
			},
			// 用户领取优惠券
			receiveCoupon(couponId) {
				let data = {
					promotion_id: couponId
				};
				this.$api.getCoupon(data, res => {
					if (res.status) {
						this.$common.successToShow(res.msg);
					} else {
						this.$common.errorToShow(res.msg);
					}
				});
			},
			// 统一返回筛选条件 查询条件 分页
			conditions() {
				let data = this.searchData;
				var newData = {};
				newData = this.$common.deepCopy(newData, data);
				//把data里的where换成json
				if (data.where) {
					newData.where = JSON.stringify(data.where);
				}
				//把排序换成字符串
				if (data.order) {
					var sort = data.order.key + ' ' + data.order.sort;
					if (data.order.key != 'sort') {
						sort = sort + ',sort asc'; //如果不是综合排序，增加上第二个排序优先级排序
					}
					newData.order = sort;
				} else {
					newData.order = 'sort asc';
				}
				return newData;
			},
			//取得商品数据
			getGoods: function(flag) {
				var _this = this;
				this.loadStatus = 'loading'
				_this.$api.goodsList(_this.conditions(), function(res) {
					_this.loadStatus = res.data.list && res.data.list.length >= _this.searchData.limit ?
						'more' : 'noMore'
					if (res.status) {
						if (flag) {
							_this.goodsList = [];
						}
						if (_this.searchData.page == 1) {
							_this.goodsList = res.data.list;
						} else {
							_this.goodsList = _this.goodsList.concat(res.data.list);
						}
						_this.searchData.page = _this.searchData.page + 1;
					}
				});
			}
		},
		onReachBottom() {
			if (this.loadStatus === 'more') {
				this.getGoods()
			}
		}
	};
</script>

<style scoped lang="less">
	.ruleBox {
		background-color: #fff;
		width: 90vw;
		border-radius: 10rpx;
		padding: 20rpx;
		line-height: 24px;

		.ruleBtn {
			padding: 16rpx 12rpx;
			background-color: #fec200;
			width: 300rpx;
			margin: 50rpx auto 20rpx;
			text-align: center;
			color: #fff;
			border-radius: 10rpx;

			&:active {
				background-color: #feca0f;
			}
		}
	}
	
	.point-home {
		padding-bottom: 120rpx;
	}

	.topBox {
		position: relative;
		width: 100vw;
		height: 398rpx;
		color: #fff;

		>img {
			width: 100%;
			height: 100%;
		}

		.top {
			position: absolute;
			top: 24rpx;
			/*  #ifdef  MP-WEIXIN  */
			top: 0;
			/*  #endif  */
			left: 20rpx;
			width: calc(100vw - 40rpx);
			display: flex;
			flex-direction: column;
			// justify-content: center;
			// align-items: center;
			.search-c {
			// 	/* #ifdef MP*/
			// 	width: 468rpx;
			// 	/* #endif */
				
			// 	/* #ifdef H5*/
			// 	width: 710rpx;
			// 	/* #endif */
				height: 72rpx;
				background: #ff7572;
			// 	border-radius: 30rpx;
			// 	display: flex;
			// 	align-items: center;
			// 	margin: 24rpx 0 0 20rpx;

			// 	input {
			// 		font-size: 24rpx;
			// 		width: 100%;
			// 	}
			}

			.point {
				// width: 208rpx;
				height: 40rpx;
				font-size: 28rpx;
				color: #fff;
				margin: 20rpx 0 24rpx 20rpx;
			}
		}

		.topImage {
			width: 100%;
			height: 402rpx;
		}

		// .infoBox {
		// 	height: 80rpx;
		// 	margin-top: 60rpx;
		// 	.info {
		// 		height: 80rpx;
		// 		font-size: 28rpx;
		// 		background-size: 100%;
		// 		> img {
		// 			width: 56rpx;
		// 			height: 56rpx;
		// 			margin-right: 12rpx;
		// 			border-radius: 50%;
		// 		}
		// 	}
		// }
		// .integral {
		// 	font-size: 80rpx;
		// }
		// .rule {
		// 	// color: #4d4d4d;
		// 	margin-top: 20rpx;
		// 	font-size: 24rpx;
		// }
	}

	.swiper-box {
		height: 214rpx;
		position: relative;
		/* #ifdef H5*/
		height: 134rpx;
		/* #endif */

		.swiper {
			padding: 0 20rpx;
			position: absolute;
			height: 360rpx;
			width: 100%;
			top: -150rpx;
			 	/* #ifdef H5*/
				top: -238rpx;
			 	/* #endif */
			box-sizing: border-box;
			left: 0;

			>swiper-item {
				height: 240rpx;
				width: 694rpx;
				border-radius: 16rpx;
				overflow: hidden;
			}

			.swiperImg {
				width: 100%;
				height: 100%;
			}
		}
	}

	.tablist {
		margin: 24rpx 20rpx;
		height: 160rpx;
		background: #ffffff;
		border-radius: 16rpx;
		display: flex;
		justify-content: space-around;
		align-items: center;

		.tabitem {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			font-weight: 300;
			color: #0e1433;

			image {
				width: 90rpx;
				height: 90rpx;
				margin-bottom: 6rpx;
			}
			
			text {
				font-size: 24rpx;
			}
		}
	}

	.goods {
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		border-radius: 10rpx;
		overflow: hidden;
		padding: 20rpx 28rpx 0;
		color: #1a1a1a;
	}

	.goodsList {
		width: 340rpx;
		margin-top: 20rpx;
		border-radius: 10rpx;
		overflow: hidden;
		box-sizing: border-box;
	}

	.goodsName {
		height: 44rpx;
		overflow: hidden;
		white-space: nowrap;
		text-overflow: ellipsis;
		color: #0e1433;
		font-size: 26rpx;
	}

	.goodsdes {
		font-weight: 300;
		color: #7e818c;
		height: 60rpx;
		font-size: 24rpx;
		overflow: hidden;
		text-overflow: ellipsis; //当对象内文本溢出时显示省略标记
		display: -webkit-box;
		-webkit-line-clamp: 2; //这边的2指的是两行
		-webkit-box-orient: vertical;
		margin: 12rpx 0 16rpx;
	}

	.imgBox {
		width: 340rpx;
		height: 340rpx;
	}

	.desc {
		width: 340rpx;
		/* display: flex; */
		flex-direction: column;
		justify-content: space-around;
		padding: 0 22rpx 30rpx;
		background: #fff;
		margin-top: -8rpx;
	}

	.priceType {
		/* width: 126rpx; */
		height: 42rpx;
		border: 1px solid #fec200;
		border-radius: 8rpx;
		font-size: 24rpx;
		color: #fec200;
		text-align: center;
		margin: 12rpx 4rpx;
		line-height: 42rpx;
		display: inline-block;
		padding: 0 10rpx;
	}

	.price {
		color: #FF4444;
		font-size: 32rpx;
		// font-size: 36rpx;
		// font-weight: 700;
	}

	.price-box {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-top: 4rpx;

		.primar {
			font-weight: 300;
			text-decoration: line-through;
			color: #7e818c;
			font-size: 24rpx;
		}

		.pay {
			width: 80rpx;
			height: 44rpx;
			background: #ff4444;
			border-radius: 8rpx;
			font-weight: 300;
			line-height: 44rpx;
			text-align: center;
			color: #ffffff;
			font-size: 24rpx;
		}
	}

	.goods-none {
		text-align: center;
		padding: 200upx 0;
	}

	.goods-none-img {
		width: 274upx;
		height: 274upx;
	}

	.rinkBox {
		position: fixed;
		right: 0;
		top: 50%;
		transform: rotateY(-50%);
		display: flex;
		flex-direction: column;
		align-items: center;
		color: #1A1A1A;
		font-size: 20rpx;
		width: 120rpx;
		height: 110rpx;
		box-shadow: 0px 0px 12px rgba(0, 0, 0, 0.16);
		border-radius: 110rpx 0px 0px 110rpx;

		&:active {
			background: #efefef;
		}

		>image {
			width: 72rpx;
			height: 70rpx;
		}
	}
</style>