<template>
	<view>
		<view class="wrap">
			<view class="top">
				<image src="../static/images/point_bg.png" mode="widthFix"></image>
				<view class="topname" v-if="rinkList.length > 0">
					<image :src="rinkList[0].avatar" mode="widthFix"></image>
					<view>{{rinkList[0].nickname}}</view>
				</view>
				<view class="topname two" v-if="rinkList.length > 1">
					<image :src="rinkList[1].avatar" mode="widthFix"></image>
					<view>{{rinkList[1].nickname}}</view>
				</view>
				<view class="topname three" v-if="rinkList.length > 2">
					<image :src="rinkList[2].avatar" mode="widthFix"></image>
					<view>{{rinkList[2].nickname}}</view>
				</view>
			</view>
			<view class="rinkBox" v-if="rinkList.length > 0">
				<view class="list title">
					<view>排名</view>
					<view>昵称</view>
					<view>累计积分</view>
				</view>
				<view class="list" v-for="(item, index) in rinkList" :key="index">
					<view class="grade">{{ item.rownum }}</view>
					<view class="info">
						<!-- <image class="userImg" :src="item.avatar" mode=""></image> -->
						<view class="">
							<view class="">{{item.nickname||""}}</view>
							<!-- <view class="vipDesc">{{item.grade_name||""}}</view> -->
						</view>
					</view>
					<view class="num">{{item.point||"0"}}</view>
				</view>
				
			</view>
		
			<uni-load-more :status="loadStatus"></uni-load-more>
			<!-- 规则弹窗 -->
			<uni-popup ref="popupRule">
				<view class="ruleBox">
					<view class="" v-for="(item,index) in pointRule">{{index+1}}.{{item}}</view>
					<view class="ruleBtn" @click="closePop">知道了</view>
				</view>
			</uni-popup>
		</view>
	</view>
</template>

<script>
	import {
		pointRule
	} from '@/config/config.js';
	export default {
		data() {
			return {
				rinkList: [],
				where: {
					page: 1,
					limit: 20
				},
				loadStatus: 'more',
				currentUserInfo: {},
				pointRule: pointRule
			};
		},
		onLoad() {
			this.getSalesRanking();
		},
		methods: {
			openRule() {
				let articleId = this.$store.state.config.point_rule_id;
				this.$common.navigateTo('/pageactivity/article/index?id_type=1&id=' + articleId);
			},
			closePop() {
				this.$refs.popupRule.close()
			},
			getSalesRanking() {
				let data = {
					page: this.where.page,
					limit: this.where.limit
				};
				let that = this;
				that.loadStatus = 'loading';
				this.$api.getPointRanking(data, res => {
					that.loadStatus = res.data.list && res.data.list.length >= that.where.limit ? 'more' :
						'noMore';
					console.log(res);
					if (res.status) {
						if (that.where.page == 1) {
							that.rinkList = that.rinkList.concat(res.data.list);
							that.currentUserInfo = res.data.current_user;
						} else {
							that.rinkList = res.data.list;
						}
						that.where.page = that.where.page + 1;
					}
				});
			},
			detail() {
				uni.navigateTo({
					url: '/pagemember/integral/index'
				});
			}
		},
		onReachBottom() {
			if (this.loadStatus === 'more') {
				this.getSalesRanking();
			}
		}
	};
</script>

<style lang="less" scoped>
	.ruleBox {
		background-color: #fff;
		width: 90vw;
		border-radius: 10rpx;
		padding: 20rpx;
		line-height: 24px;

		.ruleBtn {
			padding: 16rpx 12rpx;
			background-color: #fec200;
			width: 300rpx;
			margin: 50rpx auto 20rpx;
			text-align: center;
			color: #fff;
			border-radius: 10rpx;

			&:active {
				background-color: #feca0f;
			}
		}
	}

	view {
		box-sizing: border-box;
	}

	.wrap {
		background-color: #fff;
	}

	.info {
		width: 30%;
		display: flex;
		align-items: center;
	}

	.top {
		display: flex;
		justify-content: space-between;
		padding: 64rpx 28rpx 46rpx;
		color: #1a1a1a;
		font-size: 28rpx;
		align-items: center;
		background-color: #30A7F6;
		height: 400rpx;
		position: relative;

		>image {
			width: 710rpx;
			position: absolute;
			bottom: -40rpx;
		}

		.topname {
			position: absolute;
			z-index: 10;
			left: 50%;
			transform: translateX(-50%);
			bottom: 60rpx;
			font-weight: 400;
			text-align: center;
			color: #1685ce;
			border-radius: 50%;

			>image {
				width: 124rpx;
			}
		}

		.two {
			left: 20%;
			bottom: 50rpx;
			font-size: 24rpx;

			>image {
				width: 120rpx;
			}
		}

		.three {
			left: 82%;
			bottom: 50rpx;
			font-size: 24rpx;

			>image {
				width: 120rpx;
			}
		}
	}

	.rinkBox {
		background-color: #fff;
		border-radius: 20rpx 20rpx 0 0;
		width: 100%;
		padding: 60rpx 30rpx;
		font-size: 32rpx;
		color: #1a1a1a;
		min-height: calc(100vh - 400rpx);
		position: relative;
		top: -20rpx;
		z-index: 999;

		.list {
			display: flex;
			align-items: center;
			margin-bottom: 50rpx;
			justify-content: space-around;
			font-size: 28rpx;
			color: #0e1433;
		}

		.title {
			height: 60rpx;
			background: #f0f3f5;
			border-radius: 10rpx;
			font-size: 24rpx;
			color: #7e818c;
		}

		.grade,
		.info,
		.num {
			width: 33%;
			text-align: center;
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
		}
	}
</style>