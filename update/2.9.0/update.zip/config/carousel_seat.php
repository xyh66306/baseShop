<?php
/**
 *
 *  广告位模板配置
 *
 */

return [
    'list' => [
        '首页幻灯片广告位' => 'tpl1_slider',
        '分类页广告位'   => 'tpl1_class_banner1',
        '文章顶部广告图'   => 'pc_article_top',
        '积分商城首页幻灯片'   => 'point_mall_banner',
    ]
];